# Camera

Una aplicación simple de PhoneGap que usa la cámara y aplica filtros a la imagen resultante

## Uso

Servimos la aplicación móvil usando

    phonegap serve

Y luego accedemos desde [PhoneGap Developer App](http://docs.phonegap.com/getting-started/2-install-mobile-app/)

Aplicación creada para el curso online "Creando Apps. Introducción a la programación de aplicaciones móviles."
